﻿using Windows.UI.Xaml.Controls;

namespace animaisclap
{
    public sealed partial class MainPage : Page
    {
    }
}
